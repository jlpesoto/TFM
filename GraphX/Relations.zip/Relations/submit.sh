spark-submit \
  --class "Relations" \
  --master local[4] \
  target/scala-2.11/relations_2.11-1.0.jar
