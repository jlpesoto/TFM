spark-submit \
  --class "Time" \
  --master local[4] \
  target/scala-2.11/time_2.11-1.0.jar
